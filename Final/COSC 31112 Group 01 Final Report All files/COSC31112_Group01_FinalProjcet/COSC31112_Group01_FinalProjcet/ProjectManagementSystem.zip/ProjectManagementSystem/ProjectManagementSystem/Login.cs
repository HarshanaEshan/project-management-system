﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjectManagementSystem
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            if (textUser.Text == "Admin1" && textPassword.Text == "admin1") {
                Home h1 = new Home();
                this.Hide();
                h1.ShowDialog();
                this.Close();
            }
            else
            {
                MessageBox.Show("Invalid User Name or Password.. Check Again...","Error", MessageBoxButtons.OK ,MessageBoxIcon.Error);
                textUser.Clear();
                textPassword.Clear();
            };
        }
    }
}
